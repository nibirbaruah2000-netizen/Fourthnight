"""Pure permission and role-hierarchy rules. No I/O, so they are easy to test."""
from typing import Any, Optional


def has_staff_role(member: Any, mod_role_id: Optional[int]) -> bool:
    """True if the member holds the server's configured moderator role."""
    if not mod_role_id:
        return False
    return any(role.id == mod_role_id for role in member.roles)


def check_identity(
    actor_id: int, target_id: int, bot_id: int, owner_id: Optional[int]
) -> Optional[str]:
    """Reject punishing the bot, yourself, or the server owner. Returns an error message or None."""
    if target_id == bot_id:
        return "I can't moderate myself."
    if target_id == actor_id:
        return "You can't moderate yourself."
    if owner_id is not None and target_id == owner_id:
        return "You can't moderate the server owner."
    return None


def check_hierarchy(actor: Any, target: Any, bot: Any, owner_id: Optional[int]) -> Optional[str]:
    """Full check for a member target. Returns an error message or None if allowed."""
    error = check_identity(actor.id, target.id, bot.id, owner_id)
    if error:
        return error

    if actor.id != owner_id and target.top_role.position >= actor.top_role.position:
        return "That member has an equal or higher role than you."

    if target.top_role.position >= bot.top_role.position:
        return "That member's highest role is at or above my highest role, so I can't act on them."

    return None
