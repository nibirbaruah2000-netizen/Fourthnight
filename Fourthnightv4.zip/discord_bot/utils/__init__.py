"""Shared helpers: permissions, checks, and embeds."""
