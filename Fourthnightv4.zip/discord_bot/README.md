# Fourthnight

A multi-server Discord moderation bot built with discord.py 2.x. Each server gets its own configuration (moderator role, log channel, warning thresholds). Settings never leak between servers.

## Features

- Moderation slash commands: `/kick`, `/ban`, `/unban`, `/timeout`, `/untimeout`, `/warn`, `/warnings`, `/clearwarnings`, `/purge`, `/slowmode`, `/lock`, `/unlock`
- Per-server moderation cases with sequential numbers (Case #1, #2, ...), viewable with `/case` and `/cases`
- Configurable automatic punishments at warning thresholds
- Role-hierarchy checks: the bot won't act on the server owner, the bot itself, yourself, or members whose roles are equal to or above yours or the bot's
- Per-server settings via `/config show|modrole|logchannel|thresholds`
- Shard-ready (`AutoShardedBot`), async database access with SQLAlchemy 2.x

## Project layout

```
main.py                 entry point
config.py               environment settings
bot/client.py           bot class, cog loading, command error handling
database/               models, session, repositories (guild-scoped queries)
cogs/moderation.py      moderation commands
cogs/administration.py  /config commands
utils/                  permission rules, command checks, embeds
tests/                  pytest suite
```

## 1. Discord Developer Portal setup

1. Go to https://discord.com/developers/applications and create an application.
2. Open **Bot**, click **Reset Token**, and copy the token. Put it in `.env`. Never share it.
3. Under **Privileged Gateway Intents**, enable **Server Members Intent**. The bot needs it for role-hierarchy checks. The bot does not read message content, so leave Message Content off.

## 2. Invite link (OAuth2)

Open **OAuth2 → URL Generator**:

- Scopes: `bot` and `applications.commands`. Do not select Administrator.
- Bot permissions: Kick Members, Ban Members, Moderate Members, Manage Messages, Manage Channels, View Channels, Send Messages, Embed Links, Read Message History.

Open the generated URL to add the bot to a server.

## 3. Configuration

Copy `.env.example` to `.env` and fill in:

| Variable | Purpose |
|---|---|
| `DISCORD_TOKEN` | Bot token (required) |
| `DATABASE_URL` | SQLAlchemy URL. Defaults to local SQLite. |
| `OWNER_ID` | Your Discord user ID (optional) |
| `DEV_GUILD_ID` | Server where commands sync instantly during development |
| `LOG_LEVEL` | `DEBUG`, `INFO`, `WARNING`, or `ERROR` |
| `SYNC_COMMANDS` | `true` to register slash commands on startup. Set back to `false` afterwards. |
| `POSTGRES_*` | Used by docker-compose to create the database container |

## 4. Running locally

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # then edit it
SYNC_COMMANDS=true python main.py   # first run only, to register commands
python main.py
```

## 5. Running with Docker (VPS)

Set `POSTGRES_PASSWORD` and the other values in `.env`, then:

```bash
docker compose up -d --build
docker compose logs -f bot          # view logs
docker compose restart bot          # restart
```

The `db` service stores data in the `pgdata` volume, so it survives container rebuilds. The bot restarts automatically after crashes (`restart: unless-stopped`).

## 6. Updating

```bash
git pull
docker compose up -d --build
```

If you changed command definitions, set `SYNC_COMMANDS=true` for one restart.

## 7. Backups (PostgreSQL)

```bash
docker compose exec db sh -c 'pg_dump -U "$POSTGRES_USER" "$POSTGRES_DB"' > backup.sql
```

Restore:

```bash
docker compose exec -T db sh -c 'psql -U "$POSTGRES_USER" "$POSTGRES_DB"' < backup.sql
```

Keep passwords in `.env`, not on the command line, so they don't end up in shell history.

## 8. Tests

```bash
pytest
```

## 9. Troubleshooting

- **Commands don't appear:** run once with `SYNC_COMMANDS=true`. Global sync can take up to an hour. Set `DEV_GUILD_ID` to see changes right away.
- **"Missing permissions" errors:** check the bot's role is above the roles it needs to act on, and that it has the permissions listed above.
- **"Server Members Intent" error on startup:** enable it in the Developer Portal (step 1).
- **Startup fails with `DISCORD_TOKEN is not set`:** check that `.env` exists in the project folder.

## 10. Current limitations and next steps

- Schema changes use `create_all` at startup. Add Alembic migrations before changing existing tables in production.
- Not yet built: AutoMod, raid protection, economy, leveling, tickets, welcome messages, logging cog, `/nick`, `/mute`, `/massban`, `/softban`, and `/editcase` or `/deletecase`.
- Caching: configs are read from the database on each command. Add a cache with invalidation once traffic grows.
