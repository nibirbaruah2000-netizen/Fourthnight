"""Shops, items, and trading. Any server's shop can be used from any server."""
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from utils.economy import fmt

SELL_RATIO = 0.5


class TradeView(discord.ui.View):
    """Recipient accepts or declines an item-for-coins offer."""

    def __init__(self, repo, seller, buyer, item, quantity: int, price: int) -> None:
        super().__init__(timeout=120)
        self.repo = repo
        self.seller = seller
        self.buyer = buyer
        self.item = item
        self.quantity = quantity
        self.price = price
        self.message: discord.Message | None = None

    def _disable(self) -> None:
        for child in self.children:
            if isinstance(child, discord.ui.Button):
                child.disabled = True
        self.stop()

    @discord.ui.button(label="Accept", style=discord.ButtonStyle.success)
    async def accept(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        if interaction.user.id != self.buyer.id:
            await interaction.response.send_message("Only the recipient can accept this trade.", ephemeral=True)
            return
        ok = await self.repo.execute_trade(self.seller.id, self.buyer.id, self.item.id, self.quantity, self.price)
        self._disable()
        if ok:
            text = f"Trade complete: {self.buyer.mention} received {self.quantity}× **{self.item.name}**."
        else:
            text = "Trade failed. Someone no longer has the items or the coins."
        await interaction.response.edit_message(content=text, view=self)

    @discord.ui.button(label="Decline", style=discord.ButtonStyle.danger)
    async def decline(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        if interaction.user.id not in (self.buyer.id, self.seller.id):
            await interaction.response.send_message("This trade isn't yours.", ephemeral=True)
            return
        self._disable()
        await interaction.response.edit_message(content="Trade declined.", view=self)

    async def on_timeout(self) -> None:
        self._disable()
        if self.message is not None:
            try:
                await self.message.edit(content="Trade expired.", view=self)
            except discord.HTTPException:
                pass


class Shop(commands.Cog):
    """Shop browsing, buying, selling, trading, and server admin for items and coins."""

    eco = app_commands.Group(
        name="eco",
        description="Economy administration.",
        default_permissions=discord.Permissions(administrator=True),
        guild_only=True,
    )
    shopadmin = app_commands.Group(
        name="shopadmin",
        description="Manage this server's shop.",
        default_permissions=discord.Permissions(manage_guild=True),
        guild_only=True,
    )

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @property
    def repo(self):
        return self.bot.economy_repo

    @app_commands.command(name="shop", description="Browse a server's shop.")
    @app_commands.describe(server_id="Server ID to browse. Defaults to this server.")
    async def shop(self, interaction: discord.Interaction, server_id: Optional[str] = None) -> None:
        guild_id = interaction.guild.id if interaction.guild else None
        if server_id:
            if not server_id.isdigit():
                await interaction.response.send_message("That isn't a valid server ID.", ephemeral=True)
                return
            guild_id = int(server_id)
        if guild_id is None:
            await interaction.response.send_message("Pick a server ID to browse.", ephemeral=True)
            return

        items = await self.repo.list_items(guild_id)
        guild = self.bot.get_guild(guild_id)
        title = f"{guild.name} shop" if guild else f"Shop {guild_id}"
        embed = discord.Embed(title=title, colour=discord.Colour.gold())
        if not items:
            embed.description = "No items for sale yet."
        for item in items:
            embed.add_field(
                name=f"#{item.id} · {item.name}",
                value=f"{fmt(item.price)}\n{item.description or 'No description.'}",
                inline=False,
            )
        embed.set_footer(text="Buy with /buy item_id. Items work across all servers.")
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="buy", description="Buy an item from any server's shop by its ID.")
    @app_commands.describe(item_id="The item's ID from /shop.", quantity="How many to buy.")
    async def buy(
        self, interaction: discord.Interaction, item_id: int, quantity: app_commands.Range[int, 1, 100] = 1
    ) -> None:
        item = await self.repo.get_item(item_id)
        if item is None:
            await interaction.response.send_message("No item with that ID.", ephemeral=True)
            return
        total = item.price * quantity
        if not await self.repo.purchase(interaction.user.id, item.id, quantity, total):
            await interaction.response.send_message(f"You need {fmt(total)} to buy that.", ephemeral=True)
            return
        await interaction.response.send_message(
            f"You bought {quantity}× **{item.name}** for {fmt(total)}."
        )

    @app_commands.command(name="sell", description="Sell an item back for half its shop price.")
    @app_commands.describe(item_id="The item's ID from /inventory.", quantity="How many to sell.")
    async def sell(
        self, interaction: discord.Interaction, item_id: int, quantity: app_commands.Range[int, 1, 100] = 1
    ) -> None:
        item = await self.repo.get_item(item_id)
        if item is None:
            await interaction.response.send_message("No item with that ID.", ephemeral=True)
            return
        payout = int(item.price * SELL_RATIO) * quantity
        if not await self.repo.sell(interaction.user.id, item.id, quantity, payout):
            await interaction.response.send_message("You don't own that many of that item.", ephemeral=True)
            return
        await interaction.response.send_message(f"Sold {quantity}× **{item.name}** for {fmt(payout)}.")

    @app_commands.command(name="inventory", description="See the items you own.")
    async def inventory(self, interaction: discord.Interaction) -> None:
        rows = await self.repo.list_inventory(interaction.user.id)
        if not rows:
            await interaction.response.send_message("Your inventory is empty.", ephemeral=True)
            return
        embed = discord.Embed(title=f"{interaction.user.display_name}'s inventory", colour=discord.Colour.blurple())
        for entry, item in rows[:25]:
            embed.add_field(name=f"#{item.id} · {item.name}", value=f"×{entry.quantity}", inline=True)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="trade", description="Offer an item to another member, for coins or free.")
    @app_commands.describe(
        user="Who to trade with.",
        item_id="The item you're giving, by its ID.",
        quantity="How many to give.",
        price="Coins they pay you. 0 for a gift.",
    )
    async def trade(
        self,
        interaction: discord.Interaction,
        user: discord.Member,
        item_id: int,
        quantity: app_commands.Range[int, 1, 100] = 1,
        price: app_commands.Range[int, 0, 10**9] = 0,
    ) -> None:
        if user.bot or user.id == interaction.user.id:
            await interaction.response.send_message("You can't trade with that user.", ephemeral=True)
            return
        item = await self.repo.get_item(item_id)
        if item is None:
            await interaction.response.send_message("No item with that ID.", ephemeral=True)
            return
        owned = await self.repo.get_quantity(interaction.user.id, item.id)
        if owned < quantity:
            await interaction.response.send_message(f"You only own {owned} of that item.", ephemeral=True)
            return

        offer = f"for {fmt(price)}" if price else "as a gift"
        view = TradeView(self.repo, interaction.user, user, item, quantity, price)
        await interaction.response.send_message(
            f"{user.mention}, {interaction.user.mention} offers you {quantity}× **{item.name}** {offer}.",
            view=view,
        )
        view.message = await interaction.original_response()

    # ----- admin: coins --------------------------------------------------

    @eco.command(name="give", description="Give coins to a user.")
    @app_commands.describe(user="Who receives the coins.", amount="How many coins.")
    async def eco_give(
        self, interaction: discord.Interaction, user: discord.User, amount: app_commands.Range[int, 1, 10**9]
    ) -> None:
        await self.repo.add_coins(user.id, amount)
        await interaction.response.send_message(f"Gave {fmt(amount)} to {user.mention}.", ephemeral=True)

    @eco.command(name="take", description="Take coins from a user.")
    @app_commands.describe(user="Who loses the coins.", amount="How many coins.")
    async def eco_take(
        self, interaction: discord.Interaction, user: discord.User, amount: app_commands.Range[int, 1, 10**9]
    ) -> None:
        if not await self.repo.remove_coins(user.id, amount):
            await interaction.response.send_message(f"{user.mention} doesn't have that many coins.", ephemeral=True)
            return
        await interaction.response.send_message(f"Took {fmt(amount)} from {user.mention}.", ephemeral=True)

    # ----- admin: shop items ---------------------------------------------

    @shopadmin.command(name="additem", description="Add an item to this server's shop.")
    @app_commands.describe(name="Item name.", price="Price in coins.", description="What the item is.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def shopadmin_additem(
        self,
        interaction: discord.Interaction,
        name: app_commands.Range[str, 1, 64],
        price: app_commands.Range[int, 1, 10**9],
        description: app_commands.Range[str, 0, 200] = "",
    ) -> None:
        item = await self.repo.create_item(interaction.guild.id, name, price, description, interaction.user.id)
        if item is None:
            await interaction.response.send_message("An item with that name already exists here.", ephemeral=True)
            return
        await interaction.response.send_message(
            f"Added **{item.name}** as item #{item.id} for {fmt(price)}. Buy it with `/buy {item.id}`.",
            ephemeral=True,
        )

    @shopadmin.command(name="removeitem", description="Remove an item from this server's shop.")
    @app_commands.describe(item_id="The item's ID from /shop.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def shopadmin_removeitem(self, interaction: discord.Interaction, item_id: int) -> None:
        if not await self.repo.remove_item(interaction.guild.id, item_id):
            await interaction.response.send_message("No item with that ID in this server's shop.", ephemeral=True)
            return
        await interaction.response.send_message("Item removed from the shop.", ephemeral=True)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Shop(bot))
