"""Economy commands: earn, spend, move, and protect coins. Balances are global across servers."""
import random
from datetime import timedelta
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from utils.economy import COIN, fmt, format_remaining

DAILY_REWARD = 200
WEEKLY_REWARD = 1000
WORK_RANGE = (20, 150)
ROB_COOLDOWN = timedelta(hours=1)
ROB_MIN_TARGET = 50
ROB_FINE = 100
WORK_LINES = [
    "You fixed a bike for a neighbour",
    "You walked some dogs in the park",
    "You delivered groceries across town",
    "You sold lemonade on the corner",
    "You streamed a cooking session",
]


class Economy(commands.Cog):
    """Commands for earning and moving coins."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @property
    def repo(self):
        return self.bot.economy_repo

    @app_commands.command(name="balance", description="Check your coins and bank balance.")
    @app_commands.describe(user="Whose balance to check. Defaults to you.")
    async def balance(self, interaction: discord.Interaction, user: Optional[discord.Member] = None) -> None:
        target = user or interaction.user
        wallet = await self.repo.get_wallet(target.id)
        embed = discord.Embed(title=f"{target.display_name}'s balance", colour=discord.Colour.gold())
        embed.add_field(name="Wallet", value=fmt(wallet.coins))
        embed.add_field(name="Bank", value=fmt(wallet.bank))
        embed.add_field(name="Net worth", value=fmt(wallet.coins + wallet.bank), inline=False)
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="daily", description="Claim your daily coins.")
    async def daily(self, interaction: discord.Interaction) -> None:
        uid = interaction.user.id
        remaining = await self.repo.claim_cooldown(uid, "last_daily", timedelta(hours=24))
        if remaining:
            await interaction.response.send_message(
                f"You already claimed your daily reward. Try again in {format_remaining(remaining)}.",
                ephemeral=True,
            )
            return
        await self.repo.add_coins(uid, DAILY_REWARD)
        await interaction.response.send_message(f"You claimed your daily reward of {fmt(DAILY_REWARD)}!")

    @app_commands.command(name="weekly", description="Claim your weekly coins.")
    async def weekly(self, interaction: discord.Interaction) -> None:
        uid = interaction.user.id
        remaining = await self.repo.claim_cooldown(uid, "last_weekly", timedelta(days=7))
        if remaining:
            await interaction.response.send_message(
                f"You already claimed your weekly reward. Try again in {format_remaining(remaining)}.",
                ephemeral=True,
            )
            return
        await self.repo.add_coins(uid, WEEKLY_REWARD)
        await interaction.response.send_message(f"You claimed your weekly reward of {fmt(WEEKLY_REWARD)}!")

    @app_commands.command(name="work", description="Work a job to earn coins. Cooldown: 1 hour.")
    async def work(self, interaction: discord.Interaction) -> None:
        uid = interaction.user.id
        remaining = await self.repo.claim_cooldown(uid, "last_work", timedelta(hours=1))
        if remaining:
            await interaction.response.send_message(
                f"You're tired. Work again in {format_remaining(remaining)}.", ephemeral=True
            )
            return
        earned = random.randint(*WORK_RANGE)
        await self.repo.add_coins(uid, earned)
        await interaction.response.send_message(f"{random.choice(WORK_LINES)} and earned {fmt(earned)}.")

    @app_commands.command(name="pay", description="Send coins to another member.")
    @app_commands.describe(user="Who to pay.", amount="How many coins to send.")
    async def pay(
        self, interaction: discord.Interaction, user: discord.Member, amount: app_commands.Range[int, 1, 10**9]
    ) -> None:
        if user.bot or user.id == interaction.user.id:
            await interaction.response.send_message("You can't pay that user.", ephemeral=True)
            return
        if not await self.repo.transfer(interaction.user.id, user.id, amount):
            await interaction.response.send_message("You don't have enough coins.", ephemeral=True)
            return
        await interaction.response.send_message(f"You sent {fmt(amount)} to {user.mention}.")

    @app_commands.command(name="deposit", description="Move coins from your wallet into the bank.")
    @app_commands.describe(amount="How many coins to deposit.")
    async def deposit(self, interaction: discord.Interaction, amount: app_commands.Range[int, 1, 10**9]) -> None:
        if not await self.repo.deposit(interaction.user.id, amount):
            await interaction.response.send_message("You don't have that many coins in your wallet.", ephemeral=True)
            return
        await interaction.response.send_message(f"Deposited {fmt(amount)} into your bank.")

    @app_commands.command(name="withdraw", description="Move coins from the bank into your wallet.")
    @app_commands.describe(amount="How many coins to withdraw.")
    async def withdraw(self, interaction: discord.Interaction, amount: app_commands.Range[int, 1, 10**9]) -> None:
        if not await self.repo.withdraw(interaction.user.id, amount):
            await interaction.response.send_message("You don't have that many coins in the bank.", ephemeral=True)
            return
        await interaction.response.send_message(f"Withdrew {fmt(amount)} from your bank.")

    @app_commands.command(name="rob", description="Try to steal coins from a member. Risky. Cooldown: 1 hour.")
    @app_commands.describe(user="The member to rob.")
    async def rob(self, interaction: discord.Interaction, user: discord.Member) -> None:
        robber_id = interaction.user.id
        if user.bot or user.id == robber_id:
            await interaction.response.send_message("You can't rob that user.", ephemeral=True)
            return

        target = await self.repo.get_wallet(user.id)
        if target.coins < ROB_MIN_TARGET:
            await interaction.response.send_message(
                f"{user.mention} doesn't have enough coins to be worth robbing.", ephemeral=True
            )
            return

        remaining = await self.repo.claim_cooldown(robber_id, "last_rob", ROB_COOLDOWN)
        if remaining:
            await interaction.response.send_message(
                f"Lay low for {format_remaining(remaining)} before robbing again.", ephemeral=True
            )
            return

        if random.random() < 0.5:
            stolen = max(1, int(target.coins * random.uniform(0.10, 0.30)))
            if await self.repo.transfer(user.id, robber_id, stolen):
                text = f"You robbed {fmt(stolen)} from {user.mention}!"
            else:
                text = f"{user.mention} got away before you could take anything."
        else:
            robber = await self.repo.get_wallet(robber_id)
            fine = min(ROB_FINE, robber.coins)
            if fine and await self.repo.transfer(robber_id, user.id, fine):
                text = f"You got caught and paid {fmt(fine)} to {user.mention}."
            else:
                text = "You got caught, but you had nothing to pay."
        await interaction.response.send_message(text)

    @app_commands.command(name="leaderboard", description="Show the richest users across all servers.")
    async def leaderboard(self, interaction: discord.Interaction) -> None:
        wallets = await self.repo.top_wallets(10)
        if not wallets:
            await interaction.response.send_message("Nobody has any coins yet.", ephemeral=True)
            return
        lines = [
            f"**{rank}.** <@{wallet.user_id}> · {fmt(wallet.coins + wallet.bank)}"
            for rank, wallet in enumerate(wallets, start=1)
        ]
        embed = discord.Embed(title=f"{COIN} Richest users", description="\n".join(lines), colour=discord.Colour.gold())
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="profile", description="Show a user's economy profile.")
    @app_commands.describe(user="Whose profile to show. Defaults to you.")
    async def profile(self, interaction: discord.Interaction, user: Optional[discord.Member] = None) -> None:
        target = user or interaction.user
        wallet = await self.repo.get_wallet(target.id)
        inventory = await self.repo.list_inventory(target.id)
        item_count = sum(entry.quantity for entry, _ in inventory)

        embed = discord.Embed(title=f"{target.display_name}'s profile", colour=discord.Colour.blurple())
        embed.description = wallet.bio or "No bio set."
        embed.add_field(name="Net worth", value=fmt(wallet.coins + wallet.bank))
        embed.add_field(name="Reputation", value=f"⭐ {wallet.reputation}")
        embed.add_field(name="Items owned", value=str(item_count))
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="setbio", description="Set the bio shown on your profile.")
    @app_commands.describe(text="Your new bio. Leave empty to clear it.")
    async def setbio(self, interaction: discord.Interaction, text: app_commands.Range[str, 0, 190] = "") -> None:
        await self.repo.set_bio(interaction.user.id, text or None)
        await interaction.response.send_message("Your bio has been updated.", ephemeral=True)

    @app_commands.command(name="rep", description="Give a member a reputation point. Once per day.")
    @app_commands.describe(user="The member to thank.")
    async def rep(self, interaction: discord.Interaction, user: discord.Member) -> None:
        if user.bot or user.id == interaction.user.id:
            await interaction.response.send_message("You can't give reputation to that user.", ephemeral=True)
            return
        remaining = await self.repo.claim_cooldown(interaction.user.id, "last_rep_given", timedelta(hours=24))
        if remaining:
            await interaction.response.send_message(
                f"You can give reputation again in {format_remaining(remaining)}.", ephemeral=True
            )
            return
        await self.repo.add_reputation(user.id, 1)
        await interaction.response.send_message(f"⭐ {interaction.user.mention} gave {user.mention} a reputation point!")


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Economy(bot))
