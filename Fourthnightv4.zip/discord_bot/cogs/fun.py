"""Fun commands. Slots uses coins from the shared economy."""
import hashlib
import random

import discord
from discord import app_commands
from discord.ext import commands

from utils.economy import fmt

SLOT_SYMBOLS = ["🍒", "🍋", "🔔", "⭐", "💎"]
SLOT_WEIGHTS = [4, 3, 2, 2, 1]
SLOT_MULTIPLIERS = {"🍒": 4, "🍋": 5, "🔔": 8, "⭐": 10, "💎": 25}

EIGHT_BALL = [
    "It is certain.", "Without a doubt.", "You may rely on it.", "Most likely.",
    "Outlook good.", "Signs point to yes.", "Ask again later.", "Cannot predict now.",
    "Don't count on it.", "My sources say no.", "Very doubtful.",
]
HUGS = ["{a} gives {b} a big warm hug 🤗", "{a} wraps {b} in a tight hug 💞"]
PATS = ["{a} gives {b} gentle headpats 🐾", "{a} pats {b} on the head 🥰"]
SLAPS = ["{a} slaps {b} with a wet fish 🐟", "{a} gives {b} a dramatic slap 👋"]
ROASTS = [
    "{u}, you're the reason the group chat has a 'please read the rules' pinned message.",
    "{u}, your Wi-Fi signal is weaker than your comebacks.",
    "{u}, you bring the same energy as a Monday morning.",
]
COMPLIMENTS = [
    "{u}, you make this server a better place.",
    "{u}, your ideas are genuinely good.",
    "{u}, you're someone people are glad to see online.",
]
FACTS = [
    "Octopuses have three hearts.",
    "Honey never spoils. Archaeologists have found edible honey in ancient tombs.",
    "A group of flamingos is called a flamboyance.",
    "Bananas are berries, but strawberries aren't.",
    "The shortest war in history lasted about 38 minutes.",
]
JOKES = [
    "Why did the scarecrow win an award? He was outstanding in his field.",
    "I told my computer I needed a break. Now it won't stop sending me Kit-Kat ads.",
    "Why don't skeletons fight each other? They don't have the guts.",
    "What do you call a fake noodle? An impasta.",
    "Why did the bicycle fall over? It was two tired.",
]
RPS_WINS = {("rock", "scissors"), ("paper", "rock"), ("scissors", "paper")}


class Fun(commands.Cog):
    """Games and social commands."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @app_commands.command(name="coinflip", description="Flip a coin.")
    async def coinflip(self, interaction: discord.Interaction) -> None:
        result = random.choice(["Heads", "Tails"])
        await interaction.response.send_message(f"🪙 The coin landed on **{result}**.")

    @app_commands.command(name="dice", description="Roll one or more dice.")
    @app_commands.describe(sides="Sides per die (2 to 1000).", count="How many dice (1 to 10).")
    async def dice(
        self,
        interaction: discord.Interaction,
        sides: app_commands.Range[int, 2, 1000] = 6,
        count: app_commands.Range[int, 1, 10] = 1,
    ) -> None:
        rolls = [random.randint(1, sides) for _ in range(count)]
        total = sum(rolls)
        detail = ", ".join(str(r) for r in rolls)
        suffix = f" (total {total})" if count > 1 else ""
        await interaction.response.send_message(f"🎲 Rolled {count}d{sides}: **{detail}**{suffix}")

    @app_commands.command(name="rps", description="Play rock, paper, scissors against the bot.")
    @app_commands.describe(choice="Your move.")
    @app_commands.choices(
        choice=[
            app_commands.Choice(name="Rock", value="rock"),
            app_commands.Choice(name="Paper", value="paper"),
            app_commands.Choice(name="Scissors", value="scissors"),
        ]
    )
    async def rps(self, interaction: discord.Interaction, choice: app_commands.Choice[str]) -> None:
        bot_move = random.choice(["rock", "paper", "scissors"])
        if choice.value == bot_move:
            outcome = "It's a tie!"
        elif (choice.value, bot_move) in RPS_WINS:
            outcome = "You win!"
        else:
            outcome = "I win!"
        await interaction.response.send_message(
            f"You chose **{choice.name}**, I chose **{bot_move.title()}**. {outcome}"
        )

    @app_commands.command(name="eightball", description="Ask the magic 8-ball a question.")
    @app_commands.describe(question="Your yes-or-no question.")
    async def eightball(self, interaction: discord.Interaction, question: app_commands.Range[str, 1, 200]) -> None:
        await interaction.response.send_message(f"🎱 *{question}*\n{random.choice(EIGHT_BALL)}")

    @app_commands.command(name="slots", description="Spin the slot machine. Costs coins to play.")
    @app_commands.describe(bet="How many coins to bet.")
    async def slots(self, interaction: discord.Interaction, bet: app_commands.Range[int, 1, 100000]) -> None:
        uid = interaction.user.id
        repo = self.bot.economy_repo
        if not await repo.remove_coins(uid, bet):
            await interaction.response.send_message(f"You don't have {fmt(bet)} to bet.", ephemeral=True)
            return

        reels = random.choices(SLOT_SYMBOLS, weights=SLOT_WEIGHTS, k=3)
        payout = 0
        if reels[0] == reels[1] == reels[2]:
            payout = bet * SLOT_MULTIPLIERS[reels[0]]
        elif len(set(reels)) < 3:
            payout = bet * 2
        if payout:
            await repo.add_coins(uid, payout)

        outcome = f"You won {fmt(payout)}!" if payout else "No luck this time."
        await interaction.response.send_message(f"🎰 **{' | '.join(reels)}**\n{outcome}")

    @app_commands.command(name="choose", description="Let the bot pick one option from a list.")
    @app_commands.describe(options="Options separated by commas, e.g. pizza, tacos, sushi.")
    async def choose(self, interaction: discord.Interaction, options: app_commands.Range[str, 3, 500]) -> None:
        items = [o.strip() for o in options.split(",") if o.strip()]
        if len(items) < 2:
            await interaction.response.send_message("Give me at least two options separated by commas.", ephemeral=True)
            return
        await interaction.response.send_message(f"I choose **{random.choice(items)}**.")

    @app_commands.command(name="ship", description="Calculate compatibility between two members.")
    @app_commands.describe(first="First member.", second="Second member.")
    async def ship(self, interaction: discord.Interaction, first: discord.Member, second: discord.Member) -> None:
        a, b = sorted((first.id, second.id))
        score = int(hashlib.sha256(f"{a}:{b}".encode()).hexdigest(), 16) % 101
        await interaction.response.send_message(f"💘 {first.mention} × {second.mention}: **{score}%** compatible")

    @app_commands.command(name="rate", description="Rate anything out of 10.")
    @app_commands.describe(thing="The thing to rate.")
    async def rate(self, interaction: discord.Interaction, thing: app_commands.Range[str, 1, 200]) -> None:
        await interaction.response.send_message(f"I rate **{thing}** a {random.randint(0, 10)}/10.")

    @app_commands.command(name="hug", description="Hug a member.")
    @app_commands.describe(user="Who to hug.")
    async def hug(self, interaction: discord.Interaction, user: discord.Member) -> None:
        text = random.choice(HUGS).format(a=interaction.user.mention, b=user.mention)
        await interaction.response.send_message(text)

    @app_commands.command(name="pat", description="Give a member headpats.")
    @app_commands.describe(user="Who to pat.")
    async def pat(self, interaction: discord.Interaction, user: discord.Member) -> None:
        text = random.choice(PATS).format(a=interaction.user.mention, b=user.mention)
        await interaction.response.send_message(text)

    @app_commands.command(name="slap", description="Slap a member. Playfully.")
    @app_commands.describe(user="Who to slap.")
    async def slap(self, interaction: discord.Interaction, user: discord.Member) -> None:
        text = random.choice(SLAPS).format(a=interaction.user.mention, b=user.mention)
        await interaction.response.send_message(text)

    @app_commands.command(name="roast", description="Playfully roast a member.")
    @app_commands.describe(user="Who to roast.")
    async def roast(self, interaction: discord.Interaction, user: discord.Member) -> None:
        await interaction.response.send_message(random.choice(ROASTS).format(u=user.mention))

    @app_commands.command(name="compliment", description="Compliment a member.")
    @app_commands.describe(user="Who to compliment.")
    async def compliment(self, interaction: discord.Interaction, user: discord.Member) -> None:
        await interaction.response.send_message(random.choice(COMPLIMENTS).format(u=user.mention))

    @app_commands.command(name="fact", description="Get a random fact.")
    async def fact(self, interaction: discord.Interaction) -> None:
        await interaction.response.send_message(f"📚 {random.choice(FACTS)}")

    @app_commands.command(name="joke", description="Get a random joke.")
    async def joke(self, interaction: discord.Interaction) -> None:
        await interaction.response.send_message(f"😄 {random.choice(JOKES)}")


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Fun(bot))
