"""Per-server configuration commands. Each server only edits its own settings."""
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

from utils.embeds import notice_embed


class Administration(commands.Cog):
    """Commands under /config for this server's moderation settings."""

    config = app_commands.Group(
        name="config",
        description="Configure this server's moderation settings.",
        default_permissions=discord.Permissions(manage_guild=True),
        guild_only=True,
    )

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @config.command(name="show", description="Show this server's current settings.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def show(self, interaction: discord.Interaction) -> None:
        cfg = await self.bot.guild_repo.get_config(interaction.guild.id)
        embed = discord.Embed(title="Server settings", colour=discord.Colour.blurple())
        embed.add_field(name="Moderator role", value=f"<@&{cfg.mod_role_id}>" if cfg.mod_role_id else "Not set")
        embed.add_field(name="Log channel", value=f"<#{cfg.log_channel_id}>" if cfg.log_channel_id else "Not set")
        embed.add_field(
            name="Warning thresholds",
            value=(
                f"Timeout at {cfg.warn_timeout_threshold}\n"
                f"Kick at {cfg.warn_kick_threshold}\n"
                f"Ban at {cfg.warn_ban_threshold}"
            ),
            inline=False,
        )
        embed.add_field(name="Automatic timeout", value=f"{cfg.auto_timeout_minutes} minute(s)")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @config.command(name="modrole", description="Set the role that can use moderation commands. Omit to clear.")
    @app_commands.describe(role="The staff role. Leave empty to clear.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def modrole(self, interaction: discord.Interaction, role: Optional[discord.Role] = None) -> None:
        if role is not None and role.is_default():
            await interaction.response.send_message("The @everyone role can't be the moderator role.", ephemeral=True)
            return
        await self.bot.guild_repo.update_config(interaction.guild.id, mod_role_id=role.id if role else None)
        text = f"Moderator role set to {role.mention}." if role else "Moderator role cleared."
        await interaction.response.send_message(text, ephemeral=True)

    @config.command(name="logchannel", description="Set where moderation cases are posted. Omit to clear.")
    @app_commands.describe(channel="The text channel for the mod log. Leave empty to clear.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def logchannel(
        self, interaction: discord.Interaction, channel: Optional[discord.TextChannel] = None
    ) -> None:
        await self.bot.guild_repo.update_config(
            interaction.guild.id, log_channel_id=channel.id if channel else None
        )
        text = f"Moderation log set to {channel.mention}." if channel else "Moderation log cleared."
        await interaction.response.send_message(text, ephemeral=True)

    @config.command(name="thresholds", description="Set how many warnings trigger automatic punishments.")
    @app_commands.describe(
        timeout="Warnings before a timeout.",
        kick="Warnings before a kick.",
        ban="Warnings before a ban.",
        automatic_timeout_minutes="Length of the automatic timeout (1 to 40320).",
    )
    @app_commands.checks.has_permissions(manage_guild=True)
    async def thresholds(
        self,
        interaction: discord.Interaction,
        timeout: app_commands.Range[int, 1, 100],
        kick: app_commands.Range[int, 1, 100],
        ban: app_commands.Range[int, 1, 100],
        automatic_timeout_minutes: app_commands.Range[int, 1, 40320] = 60,
    ) -> None:
        if not (timeout < kick < ban):
            await interaction.response.send_message(
                "Thresholds must increase: timeout < kick < ban.", ephemeral=True
            )
            return
        await self.bot.guild_repo.update_config(
            interaction.guild.id,
            warn_timeout_threshold=timeout,
            warn_kick_threshold=kick,
            warn_ban_threshold=ban,
            auto_timeout_minutes=automatic_timeout_minutes,
        )
        await interaction.response.send_message(
            embed=notice_embed(
                "Thresholds updated",
                f"Timeout at {timeout}, kick at {kick}, ban at {ban} warnings. "
                f"Automatic timeout: {automatic_timeout_minutes} minute(s).",
            ),
            ephemeral=True,
        )


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Administration(bot))
