"""Entry point: loads settings, configures logging, and runs the bot."""
import asyncio
import logging

from bot.client import ModBot
from config import load_settings
from database.session import Database


def configure_logging(level: str) -> None:
    """Configure root logging once at startup."""
    logging.basicConfig(
        level=level.upper(),
        format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
    )


async def run() -> None:
    """Build the bot and run it until it is stopped."""
    settings = load_settings()
    configure_logging(settings.log_level)

    database = Database(settings.database_url)
    bot = ModBot(settings, database)
    try:
        async with bot:
            await bot.start(settings.discord_token)
    finally:
        await database.close()


if __name__ == "__main__":
    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        pass
