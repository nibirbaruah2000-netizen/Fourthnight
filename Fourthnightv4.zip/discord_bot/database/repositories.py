"""Data-access layer. Every guild-scoped query filters by guild_id."""
from typing import Any

from sqlalchemy import func, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import async_sessionmaker

from database.models import GuildConfig, ModCase, WarningRecord

CONFIG_FIELDS = frozenset(
    {
        "mod_role_id",
        "log_channel_id",
        "warn_timeout_threshold",
        "warn_kick_threshold",
        "warn_ban_threshold",
        "auto_timeout_minutes",
    }
)


class GuildRepository:
    """Reads and writes per-server configuration."""

    def __init__(self, session_factory: async_sessionmaker) -> None:
        self._sessions = session_factory

    async def get_config(self, guild_id: int) -> GuildConfig:
        """Return the guild's config, creating defaults on first access."""
        async with self._sessions() as session:
            config = await session.get(GuildConfig, guild_id)
            if config is not None:
                return config

            config = GuildConfig(
                guild_id=guild_id,
                warn_timeout_threshold=3,
                warn_kick_threshold=5,
                warn_ban_threshold=7,
                auto_timeout_minutes=60,
            )
            session.add(config)
            try:
                await session.commit()
            except IntegrityError:
                # Another request created the row first.
                await session.rollback()
                config = await session.get(GuildConfig, guild_id)
            return config

    async def update_config(self, guild_id: int, **fields: Any) -> GuildConfig:
        """Update only whitelisted config fields for one guild."""
        unknown = set(fields) - CONFIG_FIELDS
        if unknown:
            raise ValueError(f"Unknown config fields: {sorted(unknown)}")

        await self.get_config(guild_id)
        async with self._sessions() as session, session.begin():
            config = await session.get(GuildConfig, guild_id)
            for key, value in fields.items():
                setattr(config, key, value)
        return config


class ModerationRepository:
    """Warnings and moderation cases, scoped per guild."""

    def __init__(self, session_factory: async_sessionmaker) -> None:
        self._sessions = session_factory

    async def add_warning(
        self, guild_id: int, user_id: int, moderator_id: int, reason: str
    ) -> WarningRecord:
        async with self._sessions() as session, session.begin():
            record = WarningRecord(
                guild_id=guild_id,
                user_id=user_id,
                moderator_id=moderator_id,
                reason=reason,
                active=True,
            )
            session.add(record)
        return record

    async def count_active_warnings(self, guild_id: int, user_id: int) -> int:
        stmt = (
            select(func.count())
            .select_from(WarningRecord)
            .where(
                WarningRecord.guild_id == guild_id,
                WarningRecord.user_id == user_id,
                WarningRecord.active.is_(True),
            )
        )
        async with self._sessions() as session:
            return (await session.execute(stmt)).scalar_one()

    async def list_active_warnings(
        self, guild_id: int, user_id: int, limit: int = 10
    ) -> list[WarningRecord]:
        stmt = (
            select(WarningRecord)
            .where(
                WarningRecord.guild_id == guild_id,
                WarningRecord.user_id == user_id,
                WarningRecord.active.is_(True),
            )
            .order_by(WarningRecord.id.desc())
            .limit(limit)
        )
        async with self._sessions() as session:
            return list((await session.execute(stmt)).scalars().all())

    async def clear_warnings(self, guild_id: int, user_id: int) -> int:
        stmt = (
            update(WarningRecord)
            .where(
                WarningRecord.guild_id == guild_id,
                WarningRecord.user_id == user_id,
                WarningRecord.active.is_(True),
            )
            .values(active=False)
        )
        async with self._sessions() as session, session.begin():
            result = await session.execute(stmt)
            return result.rowcount or 0

    async def remove_warning(self, guild_id: int, warning_id: int) -> bool:
        stmt = (
            update(WarningRecord)
            .where(
                WarningRecord.guild_id == guild_id,
                WarningRecord.id == warning_id,
                WarningRecord.active.is_(True),
            )
            .values(active=False)
        )
        async with self._sessions() as session, session.begin():
            result = await session.execute(stmt)
            return (result.rowcount or 0) == 1

    async def add_case(
        self,
        guild_id: int,
        target_id: int,
        moderator_id: int,
        action: str,
        reason: str,
        duration_seconds: int | None = None,
    ) -> ModCase:
        """Create a case with the next per-guild number, retrying on a rare number collision."""
        for attempt in range(3):
            try:
                return await self._insert_case(
                    guild_id, target_id, moderator_id, action, reason, duration_seconds
                )
            except IntegrityError:
                if attempt == 2:
                    raise
        raise RuntimeError("unreachable")

    async def _insert_case(
        self,
        guild_id: int,
        target_id: int,
        moderator_id: int,
        action: str,
        reason: str,
        duration_seconds: int | None,
    ) -> ModCase:
        async with self._sessions() as session, session.begin():
            current = await session.execute(
                select(func.max(ModCase.case_number)).where(ModCase.guild_id == guild_id)
            )
            next_number = (current.scalar_one() or 0) + 1
            case = ModCase(
                case_number=next_number,
                guild_id=guild_id,
                target_id=target_id,
                moderator_id=moderator_id,
                action=action,
                reason=reason,
                duration_seconds=duration_seconds,
                active=True,
            )
            session.add(case)
        return case

    async def get_case(self, guild_id: int, case_number: int) -> ModCase | None:
        stmt = select(ModCase).where(
            ModCase.guild_id == guild_id, ModCase.case_number == case_number
        )
        async with self._sessions() as session:
            return (await session.execute(stmt)).scalar_one_or_none()

    async def list_cases(self, guild_id: int, target_id: int, limit: int = 10) -> list[ModCase]:
        stmt = (
            select(ModCase)
            .where(ModCase.guild_id == guild_id, ModCase.target_id == target_id)
            .order_by(ModCase.case_number.desc())
            .limit(limit)
        )
        async with self._sessions() as session:
            return list((await session.execute(stmt)).scalars().all())
