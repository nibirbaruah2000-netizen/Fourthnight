"""Role-hierarchy and identity rules, tested without Discord."""
from types import SimpleNamespace as NS

from utils.permissions import check_hierarchy, has_staff_role


def member(member_id: int, position: int) -> NS:
    return NS(id=member_id, top_role=NS(position=position), roles=[])


def test_cannot_moderate_the_bot():
    actor, bot = member(1, 10), member(99, 50)
    assert check_hierarchy(actor, bot, bot, owner_id=2) == "I can't moderate myself."


def test_cannot_moderate_yourself():
    actor = member(1, 10)
    assert check_hierarchy(actor, actor, member(99, 50), owner_id=2) == "You can't moderate yourself."


def test_cannot_moderate_the_owner():
    actor, owner = member(1, 10), member(2, 1)
    assert check_hierarchy(actor, owner, member(99, 50), owner_id=2) == "You can't moderate the server owner."


def test_cannot_moderate_equal_or_higher_role():
    actor, target = member(1, 10), member(3, 10)
    assert check_hierarchy(actor, target, member(99, 50), owner_id=2) is not None


def test_cannot_moderate_when_target_is_above_bot():
    actor, target = member(1, 60), member(3, 55)
    assert check_hierarchy(actor, target, member(99, 50), owner_id=2) is not None


def test_valid_action_is_allowed():
    actor, target = member(1, 20), member(3, 5)
    assert check_hierarchy(actor, target, member(99, 50), owner_id=2) is None


def test_owner_can_act_on_higher_roles_below_bot():
    owner = member(2, 100)
    target = member(3, 40)
    assert check_hierarchy(owner, target, member(99, 50), owner_id=2) is None


def test_staff_role_detection():
    mod_role = NS(id=555)
    assert has_staff_role(NS(roles=[mod_role]), 555)
    assert not has_staff_role(NS(roles=[mod_role]), 777)
    assert not has_staff_role(NS(roles=[mod_role]), None)
